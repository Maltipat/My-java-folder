import java.util.*;
public class Arrayfirst {
    public static void main(String[] args){         
            int[] numbers = {2, 4 ,6 ,8 ,10 ,12 ,14 ,16};
            
            // Accessing elements of the array using index
            System.out.println("Element at index 0: " + numbers[0]); 
            System.out.println("Element at index 2: " + numbers[2]); 
            numbers[1] = 10;
            System.out.println("Modified element at index 1: " + numbers[1]); 
            
            int length = numbers.length;
            System.out.println("Length of the array: " + length); 
            
            
            System.out.println("Elements of the array:");
            for (int i = 0; i < numbers.length; i++) {
                System.out.println(numbers[i]);
            }
        }
    }
    
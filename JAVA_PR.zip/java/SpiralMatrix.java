import java.util.*;

public class SpiralMatrix {
    public static void PrintSPiral(int arr[][]) {
        int startcolm = 0;
        int startrow = 0;
        int endcolm = arr[0].length - 1;
        int endrow = arr.length - 1;
        while (startrow <= endrow && startcolm <= endcolm) {
            // top
            for (int j = startcolm; j <= endcolm; j++) {
                System.out.print(arr[startrow][j] + " ");
            }
            // right
            for (int i = startrow + 1; i <= endrow; i++) {
                System.out.print(arr[i][endcolm] + " ");
            }
            // bottom
            for (int j = endcolm - 1; j >= startcolm; j--) {
                if (startrow == endrow) {
                    break;
                }
                System.out.print(arr[endrow][j] + " ");
            }
            // left
            for (int i = endrow - 1; i >= startrow + 1; i--) {
                if (startcolm == endcolm) {
                    break;
                }
                System.out.print(arr[i][startcolm] + " ");
            }
            startcolm++;
            startrow++;
            endcolm--;
            endrow--;
        }
    }

    public static void main(String[] args) {
        int arr[][] = { { 1, 2, 3 }, 
                        { 4, 5, 6 }, 
                        { 7, 8, 9 }, 
                        { 10, 11, 12 } };
        PrintSPiral(arr);
    }
}

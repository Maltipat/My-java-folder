import java.util.*;
public class problemocc {
    public static int firstOccurrence(int arr[], int key) {
        int start = 0;
        int end = arr.length - 1;
        int ans = -1; // Initialize ans with a default value
        while (start <= end) {
            int mid = start + (end - start) / 2; // Calculate mid inside the loop
            if (arr[mid] == key) {
                ans = mid;
                end = mid - 1; // Update end for finding the first occurrence
            } else if (key > arr[mid]) { 
                start = mid + 1;
            } else { // "else" for key < arr[mid]
                end = mid - 1;
            }
        }
        return ans;
    }
    public static int lastOccurrence(int arr[], int key) {
        int start = 0;
        int end = arr.length - 1;
        int ans = -1; // Initialize ans with a default value
        while (start <= end) {
            int mid = start + (end - start) / 2; // Calculate mid inside the loop
            if (arr[mid] == key) {
                ans = mid;
                start = mid +1; // Update end for finding the first occurrence
            } else if (key > arr[mid]) { 
                start = mid + 1;
            } else { // "else" for key < arr[mid]
                end = mid - 1;
            }
        }
        return ans;
    }
    public static void main(String args[]) {
        int arr[] = {1, 2,3,3,3,3,3,3,3,3,4,6};
        int key = 3;
        int totaloccurrence=lastOccurrence(arr, key)-firstOccurrence(arr, key)+1;
        System.out.println("the total occurrence of 3 is:"+totaloccurrence);

        System.out.println("The index of the first occurrence is: " + firstOccurrence(arr, key));
        System.out.println("The index of the first occurrence is: " + lastOccurrence(arr, key));
    }
}

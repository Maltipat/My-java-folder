import java.util.*;
public class javsmallest {
    public static int smallestnum(int arr[]) {
        int smaller = Integer.MAX_VALUE;
        for (int i = 0; i < arr.length; i++) {
            if (smaller >arr[i]) {
                smaller = arr[i];
            }
        }
        return smaller;
    }

    public static void main(String args[]) {
        int arr[] = {2, 4, 6, 8, 10, 7, 9};
        System.out.println("The largest value is: " + smallestnum(arr));
    }
    
}

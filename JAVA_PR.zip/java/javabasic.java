public class javabasic{
    public static void main(String args[]){
        //int marks[]=new int[3];
        int marks[][]={12,13,14,17}{2,3,4,5};
        for(int i=0;i<=marks.length;i++){
            System.out.println(marks[i]);
        }
        
    }
}

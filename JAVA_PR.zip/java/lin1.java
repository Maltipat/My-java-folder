import java.util.*;

public class lin1 {
    public static void linearSearch(String menu[], String key) {
        for (int i = 0; i < menu.length; i++) {
            if (menu[i]==key){
                System.out.println("Key is found");
                return; // No need to continue searching once key is found
            }
        }
        System.out.println("Key is not found");
    }

    public static void main(String args[]) {
        String menu[] = {"Burger", "Pizza", "Dosha", "Sandwich", "Vada", "Rice", "Samosha", "Golgappa", "dahivada"};
        String key = "Dahi";
        linearSearch(menu, key);
    }
}

import java.util.*;
public class stock{
    public static int StockbuyandSell(int Price[]){
        int buyprices=Integer.MAX_VALUE;
        int max_profit=0;
        for(int i=0;i<Price.length;i++){
            if(buyprices<Price[i]){
                int profit=Price[i]-buyprices;
                max_profit=Math.max(max_profit, profit);

            }
            else{
                buyprices=Price[i];
            }
        }
        return max_profit;
    }
    public static void main(String[] args) {
        int Price[]={8,9,3,5,7,6};
        System.out.println("maximum profit of the stock is:"+StockbuyandSell(Price));
    }
    
}

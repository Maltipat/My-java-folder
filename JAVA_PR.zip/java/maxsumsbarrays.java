import java.util.*;
public class maxsumsbarrays {
    public static void Maximumofsubarray(int arr[]){
        int current=0;
        int maxsum=Integer.MIN_VALUE;
        for(int i=0;i<arr.length;i++){
            int start=i;
            for(int j=i;j<arr.length;j++){
                int end=j;
                for(int k=start;k<end;k++){
                    System.out.print("["+arr[k]+","+"]");
                    current+=arr[k];
                }
                System.out.println(current);
                if(maxsum<current){
                    maxsum=current;
                }
            }
        }
        System.out.print("maximum sum of subarrays are:"+maxsum);
    }
    public static void main(String args[]){
        int arr[]={2,3,4,5,6,7};
        Maximumofsubarray(arr);
    }  
}

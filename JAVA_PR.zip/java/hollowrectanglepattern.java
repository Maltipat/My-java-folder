public class hollowrectanglepattern {
    public static void hollow_rectangle(int norow, int nocolum){
        //outer loop 
        for(int i=1;i<=norow;i++){
            for(int j=1;j<=nocolum;j++){
                if(i==1 || i==norow || j==1 || j==nocolum){
                    System.out.print("*");
                }
                else{
                    System.out.print(" ");
                }
            }
            System.out.println(" ");
        }
    }
    public static void main(String args[]){
        hollow_rectangle(4,5);
    }
    
}

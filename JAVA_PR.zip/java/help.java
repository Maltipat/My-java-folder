public class help {
    public static void main(String[] args) {
        System.err.println("j");
    }
}

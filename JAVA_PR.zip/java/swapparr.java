import java.util.*;
public class swapparr {
    public static void reverse(int arr[]){
        int first=0;
        int end=arr.length-1;
        int temp=0;
        while(first<end){
            temp=arr[end];
            arr[end]=arr[first];
            arr[first]=temp;
            first++;
            end--;

        }
    }
    public static void main(String args[]){
        int arr[]={1,3,5,7,9,11,13};
        reverse(arr);
        for(int i=0;i<arr.length;i++){
            System.err.print(arr[i]+",");
        }
        System.out.println();
    }
    
}

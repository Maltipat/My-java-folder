 
import java.util.*;

public class array2pro {
    public static void arrayl(int marks[]) {
        for (int i = 0; i < marks.length; i++) { 
            marks[i] = marks[i] + 1;
        }
    }

    public static void main(String args[]) {
        int marks[] = {79, 89, 99}; 
        arrayl(marks); 
        for (int i = 0; i < marks.length; i++) { 
            System.out.print(marks[i] + " ");
        }
        System.out.println();
    }
}


public class startpattern1 {
    public static void floydsTriangle(int rows) {
        int count = 1;
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(count + " ");
                count++;
            }
            System.out.println();
        }
    }

    public static void main(String args[]) {
        floydsTriangle(5); // corrected method name to match the defined method
    }
}

import java.util.*;
public class Matrix {
    public static void main(String args[]){
        int matric[][]=new int[3][4];
        int n=matric.length;
        int m=matric[0].length;
        Scanner sc=new Scanner(System.in);
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
              matric[i][j]=sc.nextInt();
            }
        }
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                System.out.print(matric[i][j]+" ");
            }
            System.out.println();
        }
    }
    
}

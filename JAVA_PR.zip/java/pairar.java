import java.util.*;
public class pairar {
    public static void Pairofarray(int arr[]){
        int totalpair=0;
        for(int i=0;i<arr.length;i++){
            int current=arr[i];
            for(int j=i+1;j<arr.length;j++){
                System.out.print("("+current+","+arr[j]+")");
                totalpair++;
            }
            System.out.println();
        }
        System.out.println("total pair is:"+totalpair);
        
    }
    public static void main(String args[]){
        int arr[]={1,2,3,4,5,6};
        Pairofarray(arr);
    }
    
}

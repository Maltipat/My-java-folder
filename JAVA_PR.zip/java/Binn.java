import java.util.*;
public class Binn{
    public static int binarySearch(int[] number, int key) {
        int start = 0;
        int end = number.length - 1;
        int mid = (start + end) / 2;
        while (start <= end) {
            if (number[mid] == key) {
                return mid;
            }
            if (key > number[mid]) {
                start = mid + 1;
            } else {
                end = mid - 1;
            }
            mid = (start + end) / 2;
        }
        return -1;
    }   
    
    public static void main(String[] args) {
        int[] number = {2, 4, 6, 8, 10, 12, 14};
        int key = 22;
        int index=binarySearch(number, key);
        if(index==-1){
        System.out.println("The key is not found");
        }
        else{
            System.out.println("the key is found at index:"+index);
        }
    } 
}
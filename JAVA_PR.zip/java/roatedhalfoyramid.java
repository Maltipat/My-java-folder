public class roatedhalfoyramid {
    public static void pyramid(int row,int colm){
        for(int i=1;i<=row;i++ ){
            for(int j=1;j<=row-i;j++){
                System.out.print(" ");
            }
            for(int j=1;j<=i;j++){
                System.out.print("*");
            }
            System.out.println( );
        }
    }
    public static void main(String args[]){
        pyramid(4, 4);
    }
    
}

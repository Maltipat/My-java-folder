import java.util.*;
public class problempeak {
    public static int moutain(int arr[]){
        int start=0;
        int end=arr.length-1;
        while (start<end) {
            int mid=(start+end)/2;
            if(arr[mid]<arr[mid+1]){
                start=mid+1;
            }
            else{
                end=mid;
            }
        }
        return start;
    }
    public static void main(String[] args) {
        int arr[]={56,57,69,89,79,49,39,29};
        System.out.println("the peak element of array is:"+moutain(arr));
        
    }
    
}

import java.util.*;

public class hello {
    public static void main(String args[]) {
        String question = "What is the largest planet in the solar system?";
        String choice1 = "Earth";
        String choice2 = "Mars";
        String choice3 = "Jupiter";
        String correctAnswer = choice3; // Corrected variable assignment

        System.out.println(question);
        System.out.println("Choose one of the following options for the given question: " + choice1 + ", " + choice2 + ", " + choice3);

        Scanner sc = new Scanner(System.in);
        String input = sc.next();

        if (correctAnswer.equalsIgnoreCase(input)) {
            System.out.println("Your answer is correct!");
        } else {
            System.out.println("You got the wrong answer. The correct answer is " + correctAnswer);
        }
    }
}


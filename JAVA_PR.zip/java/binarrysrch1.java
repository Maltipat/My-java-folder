import java.util.*;
public class binarrysrch1 {
    public static int pivotval(int arr[]){
        int start=0;
        int end=arr.length-1;
        while (start<end) {
            int mid=(start+end)/2;
            if(arr[mid]>=arr[0]){
                start=mid+1;
            }
            else{
                end=mid;
            }
        }
        return start;
    }
    public static void main(String[] args) {
        int arr[]={3,6,7,8,9,1};
        System.out.println("The pivot is:"+pivotval(arr));
    }
    
}
